"""
Files in this module contain helper functions used in
configuration files.
"""

DELETE_WARNING = 'delete seriously? '
