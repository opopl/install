
use Data::Dumper;
print Dumper(\reference);

